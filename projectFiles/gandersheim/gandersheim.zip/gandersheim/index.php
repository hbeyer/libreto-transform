<?php 
 header("Location: gandersheim-histSubject.html"); ?>