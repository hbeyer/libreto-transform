<?php 
 header("Location: example-histSubject.html"); ?>