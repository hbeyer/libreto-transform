<?php

$catalogue = new catalogue;
$catalogue->heading = 'Sulzbacher Drucke im VD 17';
$catalogue->year = '1700';
$catalogue->description = 'Dargestellt wird ein Auszug mit 297 Titelaufnahmen aus dem VD 17. Mehrbändige Werke werden zusammengefasst';
$catalogue->geoBrowserStorageID = '714175';
$catalogue->creatorReconstruction = 'Herzog August Bibliothek Wolfenbüttel';
$catalogue->yearReconstruction = '2019';

?>
