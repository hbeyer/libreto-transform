<?php 
 header("Location: sulzbach-persName.html"); ?>