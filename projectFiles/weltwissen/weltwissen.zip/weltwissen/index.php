<?php 
 header("Location: weltwissen-histSubject.html"); ?>