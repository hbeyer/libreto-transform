<?php 
 header("Location: goethe-shelfmarkOriginal.html"); ?>