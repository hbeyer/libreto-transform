<?php

$catalogue = new catalogue;
$catalogue->owner = 'Caselius, Johannes';
$catalogue->ownerGND = '116118547';
$catalogue->heading = 'Bibliothek des Johannes Caselius';
$catalogue->title = 'Inventar der von J. Caselius der Helmstedter Bibliothek hinterlassenen Bücher';
$catalogue->year = '1619';
$catalogue->institution = 'Niedesächsisches Landesarchiv Hannover'; 
$catalogue->shelfmark = 'Cal. Br. 21 D VI Nr 3';
$catalogue->description = 'Abstract zur Bibliothek von Johannes Caselius';
$catalogue->geoBrowserStorageID = '';
$catalogue->creatorReconstruction = 'Wendel, Oppermann, Beyer';
$catalogue->yearReconstruction = '2019';

?>
