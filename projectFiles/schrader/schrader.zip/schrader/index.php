<?php 
 header("Location: schrader-histSubject.html"); ?>