<?php 
 header("Location: sturm-histSubject.html"); ?>