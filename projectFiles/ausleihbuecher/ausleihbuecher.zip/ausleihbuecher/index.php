<?php 
 header("Location: ausleihbuecher-borrower.html"); ?>